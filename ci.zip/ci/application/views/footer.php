
    <footer class="footer">
       <hr />
      <p class="pull-right">
        web test
      </p>
    </footer>
   </div>
  </body>
</html>