<!DOCTYPE HTML>
<html>
    <head>
        <title>add web test</title>
        <script>var base_url = '<?php echo base_url(); ?>'; </script>
        <link rel="stylesheet" href="http://localhost/ci_2/css/bootstrap.min.css" /></link>
        <script language="javascript" src="http://localhost/javascript/jquery-1.6.2.min.js"></script>
        <script language="javascript" src="http://localhost/javascript/javascript.js"></script>
    </head>

    <body>
        <div class="container">
            <div class="navbar">
                <div class="navbar-inner">
                    <div class="container">
                        
                    </div>
                </div><!-- /navbar-inner -->
            </div>